from flask import Flask, jsonify, request, render_template, redirect, url_for
from pymongo import MongoClient
import json

app = Flask(__name__)

@app.route('/api', methods=['GET'])
def get_data():
    try:
        with open('data.json', 'r') as f:
            data = json.load(f)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

#MOngo Settings
MONGO_URI = "mongodb+srv://userPK:pass123@cluster0.abcde.mongodb.net/FlaskTestDB?retryWrites=true&w=majority&appName=FlaskDemo"
client = MongoClient(MONGO_URI)
db = client["FlaskTestDB"]
collection = db["Names"]

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            email = request.form.get('email')

            if not name or not email:
                raise ValueError("All fields are required")

            collection.insert_one({"name": name, "email": email})
            return redirect(url_for('success'))

        except Exception as e:
            return render_template('form.html', error=str(e))
        
    return render_template('form.html')


@app.route('/success')
def success():
    return render_template('success.html')


if __name__ == '__main__':
    app.run(debug=True)
